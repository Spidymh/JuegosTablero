package es.ucm.fdi.tp.view;


	public enum Shape {
		CIRCLE, RECTANGLE, BKNIGHT, WKNIGHT, BBISHOP, WBISHOP, BKING, WKING,
		BQUEEN, WQUEEN, BPAWN, WPAWN, BROOK, WROOK
	}

