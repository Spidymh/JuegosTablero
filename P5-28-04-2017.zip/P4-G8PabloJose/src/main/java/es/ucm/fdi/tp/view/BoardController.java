package es.ucm.fdi.tp.view;

import es.ucm.fdi.tp.base.model.GameAction;
import es.ucm.fdi.tp.base.model.GameState;

public class BoardController <S extends GameState<S,A>, A extends GameAction<S,A>> {

}
