package es.ucm.fdi.tp.view;

public class punto {

	public punto(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	private int x;
	private int y;
		
	public int getX(){return this.x;}
	public int getY(){return this.y;}

}
